#include<iostream>
#include<conio.h>
#include<fstream>
#include<windows.h>

using namespace std;
class bank_Accounts {
	private:
		string user_id,password,name,fathername,address,phoneNumber;
		int pin_code;
		float T_balance;

	public:
		void menu_bank();
		void bank_mangement_system();
		void new_user_signup();
		void already_user();
		void deposit_money();
		void withdraw_money();
		void transfer_money();
		void utility_bills();
		void mobilerecharge();
		void edit_user();
        void delete_record();
        void all_record();


};
void bank_Accounts::menu_bank() {
p:  //label to visit menu again and again
	system("cls");
	int choice;
	char ch;
	string pinn,passcode,email;
	cout<<"1.BANK MANGEMENT SYSTEM"<<endl;
	cout<<"2.Exit"<<endl;
	cout << "Enter your choice: ";
	cin >> choice;

	if (choice == 1) {
		system("cls");
		cout << "\n\n\t\t\tMangement Login Account";
		cout << "\n\n Enter your email \t\t:";
		cin >> email;
		cout << "\n\nEnter pin code (5 digits only) \t\t:";
		cin>>pinn;
		cout<<"\n\n Enter your Password:\t\t";
		cin>>passcode;
		if (email == "m@gmail.com" && pinn == "11111" && passcode == "malik") {

			bank_mangement_system();
		} else {
			cout << "\n\n Your Email or Pin or Password is Wrong" << endl;
		}
	} else if (choice == 2) {
		exit(0);
	} else {
		cout << "Enter valid option....PLEASE";
	}

	getch(); // get chracter
	goto p; // go to label p
}
void bank_Accounts::bank_mangement_system() {
p:
	system("cls");
	int choice;
	cout<<"\n\n\t\t BANK ACCOUNTS SYSTEM";
	cout<<"\n\n 1. New Account Login";
	cout<<"\n 2.  Check Old Account";
	cout<<"\n 3. Deposit Money";
	cout<<"\n 4. Withdraw Moeny";
	cout<<"\n 5. Transfer Money";
	cout<<"\n 6. Utility Bills Payment";
	cout<<"\n 7. Mobile Recharge";;
	cout<<"\n 8. Edit User Record";
	cout<<"\n 9. Delelte user Record               ";
	cout<<"\n 10.show all Records           ";
	cout<<"\n 11. Go back ";
	cin>>choice;
	switch(choice) {
		case 1:
			new_user_signup();
			break;
		case 2:
			already_user();
			break;
		case 3:
			deposit_money();
			break;
		case 4:
			withdraw_money();
			break;
		case 5:
			transfer_money();
			break;
		case 6:
			utility_bills();
			break;
		case 7:
			mobilerecharge();
			break;
		case 8:
			edit_user();
			break;
		case 9:
			delete_record();
			break;
		case 10:
			all_record();
			break;
		case 11:
			menu_bank();
			break;
		default:
			cout<<"Enter valid option....PLEASE";
	}
	getch();
	goto p;
}
void bank_Accounts::all_record()
{
	system("cls");
	cout<<"\t\t\tALL USER RECORDS"<<endl;
	fstream file;
	int found=0;
	file.open("bankacc.txt",ios::in);
	if(!file)
	{
		cout<<"file doesnt exist"<<endl;
		
	}
	else
	{    
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		while(!file.eof())
		{
			cout<<"USER ID   :"<<user_id<<endl;
		cout<<"NAME  :"<<name<<endl;
		cout<<"Father name   :"<<fathername<<endl;
		cout<<"address :"<<address<<endl;
		cout<<"pin code :"<<pin_code<<endl;
		cout<<"pasword :"<<password<<endl;
		cout<<"phone number  :"<<phoneNumber<<endl;
		cout<<"Total balance  :"<<T_balance<<endl;
		cout<<"======================="<<endl;
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		found++;	
		}
		file.close();
		if(found==0)
		{
			cout<<"NO RECORD EXIST UNTIL NOW"<<endl;
		}
	}
}
void bank_Accounts::edit_user() {
	system("cls");
	fstream file,file1;
	string u_id,pass;
	int found=0,pin;
	cout<<"EDIT USER RECORD"<<endl;
	file.open("bankacc.txt",ios::in);
	if(!file) {
		cout<<"FILE OPENING ERROR"<<endl;
	} else {
		cout<<"\n\n ENTER USER ID"<<endl;
		cin>>u_id;
		file1.open("bankupd.txt",ios::app|ios::out);
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		while(!file.eof()) {
			if(u_id==user_id ) {

	cout<<"\n\n EDIT Pin code (5 digit) :";
	cin>>pin;
	cout<<"\n\n EDIT Passcode :";
	cin>>pass;
	file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin<<" "<<pass<<" "<<phoneNumber<<" "<<T_balance<<"\n";
             cout<<"YOUR RECORD SUCCESSFULLY UPDATED"<<endl;
             found++;
			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance ;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==0) {
			cout<<"NO RECORD FOUND"<<endl;
		}
	}

}
void bank_Accounts::delete_record() {
	system("cls");
	fstream file,file1;
	string u_id;
	int found=0;
	cout<<"DELETE USER RECORD"<<endl;
	file.open("bankacc.txt",ios::in);
	if(!file) {
		cout<<"FILE OPENING ERROR"<<endl;
	} else {
		cout<<"\n\n ENTER USER ID"<<endl;
		cin>>u_id;
		file1.open("bankupd.txt",ios::app|ios::out);
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		while(!file.eof()) {
			if(u_id==user_id ) {

	
             cout<<"YOUR RECORD IS DELETING......!"<<endl;
             getche();
             cout<<"DELETED..!"<<endl;
             found++;
			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance ;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==0) {
			cout<<"NO RECORD FOUND"<<endl;
		}
	}

}
void bank_Accounts::utility_bills() {
	system("cls");
	cout<<"UTILITY BILLS PAYMENT"<<endl;
	fstream file,file1; //file1 for updated data
	string userid,billname;
	SYSTEMTIME x;
	float billpayment;
	int found=0;
	file.open("bankacc.txt",ios::in); //read mode
	if(!file) {
		cout<<"file ERROR"<<endl;
	} else {
		cout<<"PAY LESCO BILL"<<endl;
		cout<<"PAY WATER BILL"<<endl;
		cout<<"PAY GAS BILL"<<endl;
		cout<<"PAY INTERNET BILL"<<endl;
		cout<<"Enter ID "<<endl;
		cin>>userid;
		cout<<"Enter BILL NAME"<<endl;
		cin>>billname;
		cout<<"Enter Amount"<<endl;
		cin>>billpayment;
		file1.open("bankupd.txt",ios::app|ios::out);// opening new file for update data
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		//data comes from file to check with user id
		while(!file.eof()) {
			if(userid==user_id) {

				if(billpayment<=T_balance) {
					T_balance = T_balance-billpayment;

					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<billname<<"\t\tBILL PAY SUCCESSFULLY:"<<endl;
					cout<<"NEW BALANCE AFTER PAYMENT\t\t:"<<T_balance<<endl;
					found++;
					//sendind data to new file

				} else {
					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<"you dont have enough balance to pay bill"<<endl;
					cout<<"YOUR CURRENT BALANCE\t\t:"<<T_balance<<endl;

				}

			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==1) {
			GetSystemTime(&x);
			file.open("billrecord.txt",ios::app |ios::out);
			file<<"  "<<userid<<" PAID "<< billname<<" OF "<< billpayment<<" "<<x.wDay<<"/"<<x.wMonth<<"/"<<x.wYear<<"\n";
			file.close();
		} else {
			cout<<"user id doesnt exist"<<endl;
		}
	}

}
void bank_Accounts::mobilerecharge() {
	system("cls");
	cout<<"MOBILE RECHARGE PAYMENT"<<endl;
	fstream file,file1; //file1 for updated data
	string userid,companyname,phonenumber;
	SYSTEMTIME x;
	float payment;
	int found=0;
	file.open("bankacc.txt",ios::in); //read mode
	if(!file) {
		cout<<"file ERROR"<<endl;
	} else {

		cout<<"Enter ID "<<endl;
		cin>>userid;
		cout<<"ENTER SERVICE PROVIDER"<<endl;
		cin>>companyname;
		cout<<"Enter phone number"<<endl;
		cin>>phonenumber;
		cout<<"Enter Amount"<<endl;
		cin>>payment;
		file1.open("bankupd.txt",ios::app|ios::out);// opening new file for update data
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		//data comes from file to check with user id
		while(!file.eof()) {
			if(userid==user_id) {

				if(payment<=T_balance) {
					T_balance = T_balance-payment;

					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<companyname<<"\t\tMOBILE RECHARGE DONE ! SUCCESSFULLY:"<<endl;
					cout<<"NEW BALANCE AFTER PAYMENT\t\t:"<<T_balance<<endl;
					found++;
					//sendind data to new file

				} else {
					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<"you dont have enough balance to pay bill"<<endl;
					cout<<"YOUR CURRENT BALANCE\t\t:"<<T_balance<<endl;

				}

			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==1) {
			GetSystemTime(&x);
			file.open("rechargerecord.txt",ios::app |ios::out);
			file<<"  "<<userid<<"RECHARGED To:  "<<phonenumber<<"OF  "<<payment<<"ON   "<<x.wDay<<"/"<<x.wMonth<<"/"<<x.wYear<<"\n";
			file.close();
		} else {
			cout<<"user id doesnt exist"<<endl;
		}
	}

}

void bank_Accounts::transfer_money() {
	fstream file,file1;
	system("cls");
	float tax;
	string send_id,rev_id;
	float transfer_amount;
	int found=0;
	char ch;
	cout<<"Payment Transfer "<<endl;
	cout<<"TRANSFER WITHIN BANK (press Y)"<<endl;
	cout<<"TRANSFER TO OTHER BANK (press N)"<<endl;
	cin>>ch;
	if(ch=='Y' || ch=='y') {

		file.open("bankacc.txt",ios::in); //read mode
		if(!file) {
			cout<<"\n\nfile ERROR"<<endl;
		} else {
			cout<<"\n\n Sender User ID For transaction"<<endl;
			cin>>send_id;
			cout<<"\n\n Reciver User ID for transaction"<<endl;
			cin>>rev_id;
			cout<<"Enter amount you want to transfer"<<endl;
			cin>>transfer_amount;

			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
			while(!file.eof()) {
				if(send_id==user_id && transfer_amount<=T_balance) {
					found++;
				}
				if(rev_id==user_id) {
					found++;
				}
				file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance ;
			}
			file.close();
			if(found==2) {
				file.open("bankacc.txt",ios::in);
				file1.open("bankupd.txt",ios::app|ios::out);
				file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
				while(!file.eof()) {
					if(send_id==user_id) {
						T_balance=T_balance-transfer_amount;

						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //entering record to new file

					} else if(rev_id==user_id) {
						T_balance=T_balance+transfer_amount;
						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //entering record to new file
					} else {
						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //sending those data which is not upadated
					}
					file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
				}
				file.close();
				file1.close();
				remove("bankacc.txt");
				rename("bankupd.txt","bankacc.txt");
				cout<<"\nTRANSACTION HAS DONE"<<endl;
			} else {
				cout<<"Make ID's Correct PLZ....."<<endl;
			}

		}
	} else if(ch=='N' || ch=='n') {
		file.open("bankacc.txt",ios::in); //read mode
		if(!file) {
			cout<<"\n\nfile ERROR"<<endl;
		} else {
			cout<<"\n\n Sender User ID For transaction"<<endl;
			cin>>send_id;
			cout<<"\n\n Reciver User ID for transaction"<<endl;
			cin>>rev_id;
			cout<<"Enter amount you want to transfer"<<endl;
			cin>>transfer_amount;
			cout<<"NOTE : 5% TAX ON OTHER BANK TRANSACTIONS"<<endl;
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
			while(!file.eof()) {
				if(send_id==user_id && transfer_amount<=T_balance) {
					found++;
				}
				if(rev_id==user_id) {
					found++;
				}
				file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance ;
			}
			file.close();
			if(found==2) {
				file.open("bankacc.txt",ios::in);
				file1.open("bankupd.txt",ios::app|ios::out);
				file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
				while(!file.eof()) {
					if(send_id==user_id) {
						tax=transfer_amount*0.05;
						T_balance=T_balance-transfer_amount;
						T_balance=T_balance-tax;


						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //entering record to new file

					} else if(rev_id==user_id) {
						T_balance=T_balance+transfer_amount;
						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //entering record to new file
					} else {
						file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n"; //sending those data which is not upadated
					}
					file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
				}
				file.close();
				file1.close();
				remove("bankacc.txt");
				rename("bankupd.txt","bankacc.txt");
				cout<<"\nTRANSACTION HAS DONE"<<endl;
			} else {
				cout<<"Make ID's Correct PLZ....."<<endl;
			}

		}

	}
}


void bank_Accounts::new_user_signup() {
p:
	system("cls");
	fstream file; //file variable
	int pss; //variable names taken data from files
	string nam,fath,paswrd,addrss,phN,id;
	float bal;
	cout<<"\n\n\t\t\t ADDING NEW USER";
	cout<<"\n\n USER ID :";
	cin>>user_id;
	cout<<"\n\n NAME :";
	cin>>name;
	cout<<"\n\n Father name:";
	cin>>fathername;
	cout<<"\n\n Address :";
	cin>>address;
	cout<<"\n\n Pin code (5 digit) :";
	cin>>pin_code;
	cout<<"\n\n Passcode :";
	cin>>password;
	cout<<"\n\n Phone number :";
	cin>>phoneNumber;
	cout<<"\n\n\ Current Balance :";
	cin>>T_balance;
	file.open("bankacc.txt",ios::in);  //opening file for checking id existence
	if(!file) {
		file.open("bankacc.txt",ios::app|ios::out);
		file<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
		file.close();
	} else {
		file>>id>>nam>>fath>>addrss>>pss>>paswrd>>phN>>bal;
		while(!file.eof()) {
			if(id==user_id) {
				cout<<"\n\n USER ID ALREADY EXIST";
				getch();
				goto p; //label start to new user again
			}
			file>>id>>nam>>fath>>addrss>>pss>>paswrd>>phN>>bal;
		}
		file.close();
		file.open("bankacc.txt",ios::app|ios::out);
		file<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
		file.close();  // adding new user in file successfully
	}
	cout<<"NEW USER ADD SUCCESSFULLY";

}
void bank_Accounts::deposit_money() {
	system("cls");
	cout<<"DEPOSIT ACCOUNTS"<<endl;
	fstream file,file1; //file1 for updated data
	string userid;
	float deposit;
	int found=0;
	file.open("bankacc.txt",ios::in);
	if(!file) {
		cout<<"file ERROR"<<endl;
	} else {


		cout<<"Enter ID "<<endl;
		cin>>userid;
		file1.open("bankupd.txt",ios::app|ios::out);// opening new file for update data
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		//data comes from file to check with user id
		while(!file.eof()) {
			if(userid==user_id) {
				cout<<"Enter Amount You Want to deposit "<<endl;
				cin>>deposit;
				T_balance = T_balance+deposit;

				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
				cout<<"AMOUNT HAS BEEN DEPOSITED\t\t:"<<deposit<<endl;
				cout<<"NEW BALANCE\t\t:"<<T_balance<<endl;
				//sendind data to new file
				found++;
			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==0) {
			cout<<"user id doesnt exist";
		}
	}


}

void bank_Accounts::withdraw_money() {
	system("cls");
	cout<<"WITHDRAWAL ACCOUNTS"<<endl;
	fstream file,file1; //file1 for updated data
	string userid;
	float withdraw;
	int found=0;
	file.open("bankacc.txt",ios::in); //read mode
	if(!file) {
		cout<<"file ERROR"<<endl;
	} else {
		cout<<"Enter ID "<<endl;
		cin>>userid;
		file1.open("bankupd.txt",ios::app|ios::out);// opening new file for update data
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		//data comes from file to check with user id
		while(!file.eof()) {
			if(userid==user_id) {
				cout<<"Enter Amount You Want to Withdraw "<<endl;
				cin>>withdraw;
				if(withdraw<=T_balance) {
					T_balance = T_balance-withdraw;

					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<"AMOUNT HAS BEEN Widthraw\t\t:"<<endl;
					cout<<"NEW BALANCE AFTER withdraw\t\t:"<<T_balance<<endl;
					//sendind data to new file

				} else {
					file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
					cout<<"you dont have enough balance"<<endl;
					cout<<"YOUR CURRENT BALANCE\t\t:"<<T_balance<<endl;

				}
				found++;
			} else {
				file1<<" "<<user_id<<" "<<name<<" "<<fathername<<" "<<address<<" "<<pin_code<<" "<<password<<" "<<phoneNumber<<" "<<T_balance<<"\n";
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		}
		file.close();
		file1.close();
		remove("bankacc.txt");
		rename("bankupd.txt","bankacc.txt");
		if(found==0) {
			cout<<"user id doesnt exist";
		}
	}

}

void bank_Accounts::already_user() {
	string userid;
	system("cls");
	fstream file;
	int done=0; //checking weather data has found or not
	cout<<"\n\n\t\t\t Already Exist User Account"<<endl;
	file.open("bankacc.txt",ios::in);
	if(!file) {
		cout<<"file Doesnt Exist"<<endl;
	} else {
		cout<<"Enter ID of customer"<<endl;
		cin>>userid;
		file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		//data comes from file to check with user id
		while(!file.eof()) {
			if(userid==user_id) {
				cout<<"User Id:\t\t"<<user_id<<"\nPin code:\t\t"<<pin_code<<"\nPassword:\t\t"<<password<<"\nTotal Balance:\t\t"<<T_balance;
				done++;
			}
			file>>user_id>>name>>fathername>>address>>pin_code>>password>>phoneNumber>>T_balance;
		}
		file.close();
		if(done==0) {
			cout<<"user id doesnt exist";
		}

	}
}




int main() {
	bank_Accounts object;
	object.menu_bank();  //calling menu function
}